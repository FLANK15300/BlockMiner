static class block {

  float x, y, durabity, max_durabity;
  int[] blockPos = new int[2];
  String type;
  boolean isHited = false;
  static IntDict blockTypes = new IntDict();
  static ArrayList<ImageData> img = new ArrayList<ImageData>();
  static ImageData[] crack = new ImageData[4];
  final static float blockSize = 32;
  
  static {
    blockTypes.set("grass", 0);
    blockTypes.set("dirt", 1);
    blockTypes.set("stone", 2);
    blockTypes.set("cobblestone", 3);
    blockTypes.set("iron", 4);
    blockTypes.set("gold", 5);
    
    blockTypes.set("topaz", 6);
    blockTypes.set("amethyst", 7);
    blockTypes.set("sapphire", 8);
    blockTypes.set("emerald", 9);
    blockTypes.set("ruby", 10);
    blockTypes.set("diamond", 11);
    blockTypes.set("bedrock", 12);

    img.add(new ImageData("texture/blocks/grass.png", blockSize, blockSize));
    img.add(new ImageData("texture/blocks/dirt.png", blockSize, blockSize));
    img.add(new ImageData("texture/blocks/stone.png", blockSize, blockSize));
    img.add(new ImageData("texture/blocks/cobblestone.png", blockSize, blockSize));
    img.add(new ImageData("texture/blocks/iron.png", blockSize, blockSize));
    img.add(new ImageData("texture/blocks/gold.png", blockSize, blockSize));
    img.add(new ImageData("texture/blocks/topazz.png", blockSize, blockSize));
    img.add(new ImageData("texture/blocks/amethyst2.png", blockSize, blockSize));
    img.add(new ImageData("texture/blocks/sapphire2.png", blockSize, blockSize));
    img.add(new ImageData("texture/blocks/emerald2.png", blockSize, blockSize));
    img.add(new ImageData("texture/blocks/ruby2.png", blockSize, blockSize));
    img.add(new ImageData("texture/blocks/diamond2.png", blockSize, blockSize));
    img.add(new ImageData("texture/blocks/bedrock.png", blockSize, blockSize));
    crack[0] = (new ImageData("texture/misc/crack/1.png", blockSize, blockSize));
    crack[1] = (new ImageData("texture/misc/crack/2.png", blockSize, blockSize));
    crack[2] =(new ImageData("texture/misc/crack/3.png", blockSize, blockSize));
    crack[3] = (new ImageData("texture/misc/crack/4.png", blockSize, blockSize));

  }


  block(String type, float x, float y, float durabity, int blockPosx, int blockPosy) {
    //main_game game = (main_game)Screens[2]; // Screen型のScreenの要素をmain_game型にキャストすることで、main_gameのメンバー変数を取得する
    this.type = type;
    this.x = x;
    this.y = y;
    this.max_durabity = durabity;
    this.durabity = durabity;
    this.blockPos[0] = blockPosx;
    this.blockPos[1] = blockPosy;
    
    
  }


  void draw() {
  
  if(this.type == "air" || this.durabity <= 0) return;
    img.get(blockTypes.get(type)).draw(x, y);
    float durabity_rate = 1.0 - (this.durabity / this.max_durabity);
    if (durabity_rate < 1.0/5.0){
    }else if (durabity_rate < 2.0/5.0){
        crack[0].draw(x, y);
    }else if (durabity_rate < 3.0/5.0){
        crack[1].draw(x, y);
    }else if (durabity_rate < 4.0/5.0){
        crack[2].draw(x, y);
    }else if (durabity_rate < 5.0/5.0){
        crack[3].draw(x, y);
    }
    
  }
  
  String hit(){
    isHited = false;
    float caledStrength = ball.strength * ball.strength_magnification;
    if(blockHitCheck(this.x, this.y, this.blockSize, this.blockSize, ball.x, ball.y, ball.size, ball.size, ball.dx, ball.dy) == 0 || this.durabity <= 0 || this.y < 200) return "";
    
    isHited = true;
    println(this.durabity);
    if (p.random(100) < ball.onePunch){
      isHited = false;
      println("ワンパン！");
      this.durabity = 0;
      return type;
    }
    
    if(this.durabity - caledStrength < 0) {
      isHited = false;
      this.durabity = 0;
      return type;
    }

    

    this.durabity -= caledStrength;
    if (this.durabity > 0) return "";
    
    return type;

  }
}

String randomBlockType(weightedItem... item){
  
  float sumWeight = 0;
  
  for (weightedItem i : item){
    sumWeight += i.weight;
  }
  
  float r = random(sumWeight);
  
  sumWeight = 0;
  for (weightedItem i : item){
    sumWeight += i.weight;
    if(r < sumWeight){
      return i.name;
    }
  }
  return "bedrock";
}

class weightedItem{
  
  String name;
  float weight;
  
  weightedItem(String name, float weight){
    
    this.name = name;
    this.weight = weight;
    
  }
  
}
