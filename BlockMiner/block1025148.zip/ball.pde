static class ball {

  static float x, y;
  static float strength;
  static float ex_ore = 0, ex_jewel = 0, ex_all = 0;
  static float size_magnification = 1;
  static float strength_magnification = 1;
  static float onePunch = 0;
  static int blockPos[] = new int[4];
  String type;
  static ArrayList<ImageData> img = new ArrayList<ImageData>();
  static float dx, dy, speed;
  
  static float defaultSize = 10;
  static float size = 10;
  final static float blockSize = 32;
  
  static {
    dx = 2;
    dy = 3;
  }


  ball(String type, float x, float y, float strength) {
    this.type = type;
    this.x = x;
    this.y = y;
    this.strength = strength;
  }


  void shoot(float speed, float angle){
    this.dx = speed * cos(angle);
    this.dy = speed * sin(angle);
  }
  
  void main(){
    
    if (this.y + size < 0) return;
    this.draw();
    this.update();
    
  }
  
  void draw() {
    
    p.fill(255);
    p.rect(this.x, this.y, size, size);
  
  }
  
  static void update(){
  
    x += dx;
    y += dy;
    
    blockPos[0] = int((x - 400) / blockSize);
    blockPos[1] = int((y - 220) / blockSize);
    blockPos[2] = int((x - 400 + dx) / blockSize);
    blockPos[3] = int((y - 220 + dy) / blockSize);
    
    dx = (x < 385 || x + size > 385 + 16 * 32) ? -dx : dx;
    dy = (y + size > p.height) ? -dy : dy;
    size = defaultSize * size_magnification;
    
    
    
    
  }
}
