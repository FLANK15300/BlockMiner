void debugInfo(){
  ArrayList<String> debugtext = new ArrayList<String>();
  switch(debugMode){
    case 1:
      textFont(Default);  
      textAlign(LEFT);
      noStroke();
      textSize(16);
      fill(0, 125);
      rect(0,0, 200, 400);
      fill(255);
      text("mouseX:" + mouseX + "\nmouseY:" + mouseY + "\nmouseButton:" + mouseButton + "\nMouse{\n    moving:" + mouse.moving + "\n    left.pressed: " + mouse.left.Pressed + "\n    left.Down: " + mouse.left.Down + "\n    left.Rleased: " + mouse.left.Released + "\n    left.Up: " + mouse.left.Up + "\n    left.state: " + mouse.left.holdTime + "\n    left.state: " + mouse.left.state + "\n}\n    key.y.state: " + keyState.getOrDefault("y", false) + "\n    key.left.state: " + keyState.getOrDefault("LEFT", false) + "\n    ball.blockPosx: " + ball.blockPos[0] + "\n    ball.blockPosy: " + ball.blockPos[1], 1, 16);
      break;
    case 2:
      textFont(Default);  
      textAlign(LEFT);
      noStroke();
      textSize(16);
      fill(0, 125);
      rect(0,0, 200, 300);
      fill(255);
      
      main_game game = (main_game)Screens[2]; // Screen型のScreenの要素をmain_game型にキャストすることで、main_gameのメンバー変数を取得する
      debugtext.add("dirt:" + game.dirt);
      debugtext.add("stone:" + game.stone);
      debugtext.add(":" + game.dirt);
      debugtext.add("iron:" + game.iron);
      debugtext.add("dirt:" + game.gold);
      debugtext.add("topaz" + game.topaz);
      debugtext.add("topaz:" + game.topaz);
      //text(debugtext, 1, 16);
  
  }
  
  
  textFont(F_pixel);
}
